<?php 
session_start();
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    foreach($_POST as $k => $v){
        if($k=='picture')
        $_SESSION['fb_profile_pic'] = $v['data']['url'];
        else
        $_SESSION['fb_'.$k] = $v;
    }    
    echo json_encode(['status' => 'success']);
}else{
    echo json_encode(['status' => 'failed']);
}
?>