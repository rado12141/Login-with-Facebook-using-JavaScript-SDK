var logout_btn = document.getElementById('logout_btn')

window.fbAsyncInit = function() {
  FB.init({
    appId      : '831713341210942',
    cookie     : true,
    xfbml      : true,
    version    : 'v2.7'
  });
    
  FB.AppEvents.logPageView();  
  
  /**
   * Check Login Status
   */
  FB.getLoginStatus(function(response) {
    fbStatusChange(response);
  });

  
};

(function(d, s, id){
   var js, fjs = d.getElementsByTagName(s)[0];
   if (d.getElementById(id)) {return;}
   js = d.createElement(s); js.id = id;
   js.src = "https://connect.facebook.net/en_US/sdk.js";
   fjs.parentNode.insertBefore(js, fjs);
 }(document, 'script', 'facebook-jssdk'));


/**
 * After Login
 */
 function fbLogin(){
  FB.login(function(response){
    fbStatusChange(response)
  })
 }

 /**
 * Save FB User Data to Session
 */
 function fbStatusChange(loginResp){
  console.log(loginResp)
  if(loginResp.status =='connected' && (location.origin + location.pathname) == 'https://localhost/js-fb-login/login.php'){
    FB.api('/me', 'GET', {fields: 'email,name,gender,picture{url}' }, function(response) {
      if(!response.error){
        $.ajax({
          url:'sign-in.php',
          method:"POST",
          data: response,
          dataType:"JSON",
          error:function(err){
              alert("Login Failed!")
              console.error(err)
          },
          success:function(resp){
            if(resp.status == 'success'){
              location.replace('index.php');
            }else{
              alert("Login Failed!")
            }
          }
  
        })
      }else{
          alert("Login Failed!")
          console.error(response.error)
      }
      
    });
  } 
 }


 /**
  * Logout Facebook
  */
if(logout_btn !== undefined && logout_btn !== null){
  logout_btn.addEventListener('click', function(e){
    e.preventDefault()
    FB.logout(function(){
      console.log('Facebook Account has been logged out to this application.')
    })
    location.replace(this.getAttribute('href'))
  })
}
